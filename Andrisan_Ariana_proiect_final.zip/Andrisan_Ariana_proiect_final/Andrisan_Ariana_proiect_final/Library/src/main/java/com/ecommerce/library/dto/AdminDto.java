package com.ecommerce.library.dto;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor @AllArgsConstructor
public class AdminDto {
 @Size(min = 3, max = 10, message = "Invalidate first name! (3-10 characters)")
    private String firtName;
 @Size(min = 3, max = 10, message = "Invalidate last name! (3-10 characters)")
    private String lastName;
 @Size(min = 3, max = 10, message = "Invalidate password name! (5-15 characters)")
    private String username;

    private String password;

    private String repeatPassword;

}
