package repository;

import model.Admin;
import model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
    Role findByName(String username);

    Admin findByUsername(String username);
}
