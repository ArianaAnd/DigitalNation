package service;

import com.ecommerce.library.dto.AdminDto;
import model.Admin;

public interface AdminService {
    Admin findByName(String username);

    Admin findByUsername(String username);

    Admin save(AdminDto adminDto);
}
