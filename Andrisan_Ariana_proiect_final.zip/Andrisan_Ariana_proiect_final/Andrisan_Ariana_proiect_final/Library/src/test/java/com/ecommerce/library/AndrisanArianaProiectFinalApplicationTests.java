package com.ecommerce.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndrisanArianaProiectFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
